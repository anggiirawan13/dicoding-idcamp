const booksDatabase = [];

export default booksDatabase;