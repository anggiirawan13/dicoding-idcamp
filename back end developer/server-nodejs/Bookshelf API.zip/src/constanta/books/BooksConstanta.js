const baseURI = "/books";
const baseURIWithParamBookId = `${baseURI}/{bookId}`;

export { baseURI, baseURIWithParamBookId };